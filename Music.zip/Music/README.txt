CARD SURVIVOR - MÚSICA
========================

Para el estilo GÓTICO del juego:

01_Menu_Gothic    - Menú principal (oscuro, misterio)
02_Exploration    - Exploración de mazmorras
03_Exploration_2  - Exploración alternativa
04_Castle         - Castillo/Fortaleza
05_Combat         - Combate normal
06_Boss           - Jefe/Batalla épica
07_Cave           - Cuevas/Zonas oscuras
08_Village        - Aldea/Descanso

Formatos: OGG (compatible con Swift/SpriteKit)

FUENTES:
- OpenGameArt.org (gratis, CC0/CC-BY)
- Música libre de derechos

Para añadir al Xcode:
1. Arrastra la carpeta Music al proyecto
2. Usa AVAudioPlayer en Swift
3. Reproduce según el estado del juego
